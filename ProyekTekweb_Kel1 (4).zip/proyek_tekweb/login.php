<!DOCTYPE html>
<head>
    <?php
        include "includes/connection.php";

        if(isset($_POST['login'])) {
            $email = $_POST['inputEmail'];
            $password = $_POST['inputPassword'];

            $sql_login = mysqli_query($connection, "SELECT * FROM account
            WHERE email = '$email' AND password = '$password'");

            if(mysqli_num_rows($sql_login) > 0) {
                $row_admin = mysqli_fetch_array($sql_login);
                $_SESSION['inputEmail'] = $row_admin['email'];
                $_SESSION['inputPassword'] = $row_admin['password'];
                header("location:beranda.html");
            }
            else {
                echo '<script>alert("Akun tidak valid")</script>';
            }
        }
    ?>

    <title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <link rel="icon" href="images/apple icon.png" type="image/gif">
    
    <link rel="stylesheet" type="text/css" href="./templateLogin.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-10">
                <div class="card">
                    <div class="row">
                        <div class="col-5" id="image">
                            <img src="images/apple_industry.jpg">
                        </div>
                        <div class="col-6 ml-5">
                            <div class="p-5">
                                <div class="text-center">
                                    <img src="images/login_icon.png" id="loginIcon">
                                </div><br>
                                <div class="text-center">
                                    <h3>Sign In</h3>
                                </div><br>
                                <form method="POST">
                                    <input type="email" class="form-control" name="inputEmail" placeholder="Email Address"><br>
                                    <input type="password" class="form-control" name="inputPassword" placeholder="Password"><br>
                                    <input type="submit" name="login" class="btn btn-dark btn-block" value="Login"><br><br>
                                    <p>Don't have an account? <a href="createAccount.php">Register here</a></p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>