<!DOCTYPE html>
    <head>
        <title>Spesifikasi Produk</title>
        <!-- Bootstrap -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!-- Icons footer -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined">

        <link rel="icon" href="images/apple icon.png" type="image/gif">
        
        <link rel="stylesheet" type="text/css" href="./template.css">

        <?php  
            session_start();
            include "connection.php";

            if(isset($_POST['gray']))
            {
                $qbarang = "SELECT * FROM warna WHERE idproduk = 10 AND color = 'Gray' ";
                $stmt    = $conn->query($qbarang);
                foreach($stmt->fetchAll() as $row)
                {
                    $_SESSION['gray'] = $row['color'];
                }
                
            }  

            if(isset($_POST['silver']))
            {
                $qbarang = "SELECT * FROM warna WHERE idproduk = 10 AND color = 'Silver' ";
                $stmt    = $conn->query($qbarang);
                foreach($stmt->fetchAll() as $row)
                {
                    $_SESSION['silver'] = $row['color'];
                }
                
            }  

            if(isset($_POST['128']))
            {
                $qbarang = "SELECT * FROM spesifikasi WHERE idproduk = 10 AND memori = '128 GB' ";
                $stmt    = $conn->query($qbarang);
                foreach($stmt->fetchAll() as $row)
                {
                    $_SESSION['128'] = $row['memori'];
                    $_SESSION['harga'] = $row['harga'];
                }
                
            }  

            if(isset($_POST['256']))
            {
                $qbarang = "SELECT * FROM spesifikasi WHERE idproduk = 10 AND memori = '256 GB' ";
                $stmt    = $conn->query($qbarang);
                foreach($stmt->fetchAll() as $row)
                {
                    $_SESSION['256'] = $row['memori'];
                    $_SESSION['harga'] = $row['harga'];
                }
                
            }  

            if(isset($_POST['512']))
            {
                $qbarang = "SELECT * FROM spesifikasi WHERE idproduk = 10 AND memori = '512 GB' ";
                $stmt    = $conn->query($qbarang);
                foreach($stmt->fetchAll() as $row)
                {
                    $_SESSION['512'] = $row['memori'];
                    $_SESSION['harga'] = $row['harga'];
                }
                
            }  

            if(isset($_POST['1000']))
            {
                $qbarang = "SELECT * FROM spesifikasi WHERE idproduk = 10 AND memori = '1 TB' ";
                $stmt    = $conn->query($qbarang);
                foreach($stmt->fetchAll() as $row)
                {
                    $_SESSION['1000'] = $row['memori'];
                    $_SESSION['harga'] = $row['harga'];
                }
            }  

            if(isset($_POST['2000']))
            {
                $qbarang = "SELECT * FROM spesifikasi WHERE idproduk = 10 AND memori = '2 TB' ";
                $stmt    = $conn->query($qbarang);
                foreach($stmt->fetchAll() as $row)
                {
                    $_SESSION['2000'] = $row['memori'];
                    $_SESSION['harga'] = $row['harga'];
                }
            }  
        ?>  
    </head>
    <body>
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark justify-content-center">
            <ul class="navbar-nav">
                <a class="navbar-brand" href="../beranda.html">
                    <img src="images/apple.png" alt="logo" style="width:20px;">
                </a>
                <li class="nav-item">
                    <a class="nav-link" href="../beranda.html#mac">Mac</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../beranda.html#iPad">iPad</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../beranda.html#iPhone">iPhone</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../beranda.html#watch">Watch</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../beranda.html#otherAccessoris">Airpods</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../beranda.html#otherAccessoris">TV</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../langkahPembelian.html">Langkah Pembelian</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../bantuan.html">Maintenance</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../login.php">Log Out</a>
                </li>
            </ul>
        </nav>

        <div class="container" style="margin-top: 50px;">
            <div class="row">
                <div class="col-6" style="margin-left: 350px;">
                    <div class="container">
                        <div class="card" style="width:400px" style="margin-top: 20px;" >
                            <img class="card-img-top" src="Images/Ipad Pro.jpg" alt="Card image" style="width:100%">
                            <div class="card-body">
                                <h4 class="card-title">-iPad Pro 2020-</h4>
                                <p class="card-text"><b>Spesifikasi iPad Pro 2020</b></p>
                                <p class="card-text">Nama : Apple iPad Pro 2020</p>
                                <p class="card-text">Berat :  Model Wi-Fi
                                    682 g,
                                    Model Wi-Fi + Cellular
                                    684 g </p>
                                <p class="card-text">Resolusi Layar : 2732 x 2048 dengan 264 piksel</p>
                                <p class="card-text">Jenis & Ukuran Layar :  Layar Liquid Retina XDR
                                    Layar Multi-Touch dengan lampu latar LED mini 12,9 inci (diagonal) dengan teknologi IPS
                                    Sistem lampu latar 2D dengan 2.596 zona peredupan lokal dengan rangkaian penuh</p>
                                <p class="card-text"><b>Warna & Memory</b></p>
                                <p class="card-text"> Pilihan Warna :</p> 
                                <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal" style="margin-bottom: 20px;">Pilih Warna</a>
                                <p style="margin-left: 0px;">Warna Yang di Pilih: <div id="output-warna" style="margin-left: 0px;"> 
                                <?php
                                    if(isset($_SESSION['gray']))
                                    {
                                        echo $_SESSION['gray'];
                                        unset($_SESSION['gray']);
                                    } 
                                    if(isset($_SESSION['silver']))
                                    {
                                        echo $_SESSION['silver'];
                                        unset($_SESSION['silver']);
                                    }  
                                ?> 
                                </div></p> 
                                <div class="modal fade" id="myModal" role="dialog">
                                    <div class="modal-dialog">
                                    
                                      <!-- Modal content-->
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h4 class="modal-title">Pilihan Warna</h4>
                                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="#" method="POST">
                                                <button type="submit" class="btn btn-primary" name="gray">Gray</button>
                                                <button type="submit" class="btn btn-primary" name="silver">Silver</button>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                      </div>
                                      
                                    </div>
                                  </div>
                                  
                                <p class="card-text">Pilihan Memory</p>
                                <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#memori" style="margin-bottom: 20px;">Pilih Memory</a>
                                <p style="margin-left: 0px;">Memory Yang di Pilih: <div id="output-memori" style="margin-left: 0px;"> 
                                <?php
                                    if(isset($_SESSION['128']))
                                    {
                                        echo $_SESSION['128'];
                                        unset($_SESSION['128']);
                                    } 
                                    if(isset($_SESSION['256']))
                                    {
                                        echo $_SESSION['256'];
                                        unset($_SESSION['256']);
                                    }  
                                    if(isset($_SESSION['512']))
                                    {
                                        echo $_SESSION['512'];
                                        unset($_SESSION['512']);
                                    }  
                                    if(isset($_SESSION['1000']))
                                    {
                                        echo $_SESSION['1000'];
                                        unset($_SESSION['1000']);
                                    }
                                    if(isset($_SESSION['2000']))
                                    {
                                        echo $_SESSION['2000'];
                                        unset($_SESSION['2000']);
                                    }
                                ?> 
                                </div></p>
                                <div class="modal fade" id="memori" role="dialog">
                                    <div class="modal-dialog">
                                    
                                      <!-- Modal content-->
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h4 class="modal-title">Pilihan Memori</h4>
                                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="#" method="POST">
                                                <button type="submit" class="btn btn-primary" name="128">128 GB</button>
                                                <button type="submit" class="btn btn-primary" name="256">256 GB</button>
                                                <button type="submit" class="btn btn-primary" name="512">512 GB</button>
                                                <button type="submit" class="btn btn-primary" name="1000">1 TB</button>
                                                <button type="submit" class="btn btn-primary" name="2000">2 TB</button>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                      </div>
                                      
                                    </div>
                                  </div>
                                  <p style="margin-left: 0px;">Total Pembayaran: <div id="output-bayar" style="margin-left: 0px;"> 
                                  <?php  
                                    if(isset($_SESSION['harga']))
                                    {
                                        echo $_SESSION['harga'];
                                        unset($_SESSION['harga']);
                                    } 
                                    ?> 
                                    </div></p>
                                  
                                <h5 style="text-align: center;"><b>Silakan Bayar</b></h5>
                                <a href="#" class="btn btn-primary" style="margin-left: 145px;" data-toggle="modal" data-target="#bayar">Bayar</a>
                                <div class="modal fade" id="bayar" role="dialog">
                                    <div class="modal-dialog">
                                    
                                      <!-- Modal content-->
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h4 class="modal-title">Proses Pembayaran</h4>
                                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <h2 style="text-align: center;">Transaksi Anda Telah Berhasil!</h2>
                                          
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                      </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    </div>
                </div>
            </div>  
        </div>

        <footer class="page-footer pt-4 bg-dark" style="margin-top: 30px;">
            <div class="container text-center text-md-left">
                <div class="row" style="margin-top: 20px; margin-bottom: 60px;">
                    <div class="col-3">
                        <h5>About Apple</h5>
                        <ul class="list-unstyled">
                            <li>
                                <a href="#!">Newsroom</a>
                            </li>
                            <li>
                                <a href="#!">Apple Leadership</a>
                            </li>
                            <li>
                                <a href="#!">Career Opportunities</a>
                            </li>
                            <li>
                                <a href="#!">Investors</a>
                            </li>
                            <li>
                                <a href="#!">Ethics & Compliance</a>
                            </li>
                            <li>
                                <a href="#!">Events</a>
                            </li>
                            <li>
                                <a href="#!">Contact Apple</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-3">
                        <h5>Apple Values</h5>
                        <ul class="list-unstyled">
                            <li>
                                <a href="#!">Accessibility</a>
                            </li>
                            <li>
                                <a href="#!">Education</a>
                            </li>
                            <li>
                                <a href="#!">Environment</a>
                            </li>
                            <li>
                                <a href="#!">Inclusion and Diversity</a>
                            </li>
                            <li>
                                <a href="#!">Privacy</a>
                            </li>
                            <li>
                                <a href="#!">Racial Equity and Justice</a>
                            </li>
                            <li>
                                <a href="#!">Supplier Responsibility</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-3">
                        <h5>Apple Store</h5>
                        <ul class="list-unstyled">
                            <li>
                                <a href="#!">Find a Store</a>
                            </li>
                            <li>
                                <a href="#!">Genius Bar</a>
                            </li>
                            <li>
                                <a href="#!">Today at Apple</a>
                            </li>
                            <li>
                                <a href="#!">Apple Camp</a>
                            </li>
                            <li>
                                <a href="#!">Apple Store App</a>
                            </li>
                            <li>
                                <a href="#!">Returbished and Clearance</a>
                            </li>
                            <li>
                                <a href="#!">Financing</a>
                            </li>
                            <li>
                                <a href="#!">Apple Trade In</a>
                            </li>
                            <li>
                                <a href="#!">Order Status</a>
                            </li>
                            <li>
                                <a href="#!">Shopping Help</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-3">
                        <h5 class="text-uppercase">Tentang Kami.</h5>
                        <p>(032)-05347190</p>
                        <a href="https://www.google.com" class="fa fa-google"></a>
                        <a href="https://www.youtube.com" class="fa fa-youtube"></a>
                        <a href="https://www.twitter.com" class="fa fa-twitter"></a>
                        <a href="https://www.facebook.com" class="fa fa-facebook"></a>
                        <a href="https://www.instagram.com" class="fa fa-instagram"></a>
                    </div>
                </div>
            </div>
            <div class="footer-copyright text-center py-3" id="copyright">
                Copyright © 2021 Apple Inc. All rights reserved.
            </div>
        </footer>
    </body>    
</html>