-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2021 at 12:33 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `proyek_tekweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`email`, `password`) VALUES
('tes@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `idproduk` int(11) NOT NULL,
  `namaproduk` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`idproduk`, `namaproduk`) VALUES
(1, 'iPhone 13 Pro Max'),
(2, 'iPhone 13 Pro'),
(3, 'iPhone 13'),
(4, 'iPhone 12 Pro'),
(5, 'iPhone 12'),
(6, 'iPhone 12 Mini'),
(7, 'Apple Watch Series 7'),
(8, 'Apple Watch Series 6'),
(9, 'Apple Watch Series 5'),
(10, 'iPad Pro 2020'),
(11, 'iPad Air'),
(12, 'iPad Mini 6'),
(13, 'iMac 2021'),
(14, 'Macbook Pro'),
(15, 'Macbook Air'),
(16, 'Airpods Pro'),
(17, 'Apple TV'),
(18, 'Airpods Max');

-- --------------------------------------------------------

--
-- Table structure for table `spesifikasi`
--

CREATE TABLE `spesifikasi` (
  `idspesifikasi` int(10) NOT NULL,
  `memori` varchar(10) NOT NULL,
  `ukuran` varchar(10) NOT NULL,
  `harga` varchar(30) NOT NULL,
  `idproduk` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `spesifikasi`
--

INSERT INTO `spesifikasi` (`idspesifikasi`, `memori`, `ukuran`, `harga`, `idproduk`) VALUES
(1, '128 GB', '', '19.999.000', 1),
(2, '256 GB', '', '22.999.000', 1),
(3, '512 GB', '', '26.999.000', 1),
(4, '1 TB', '', '30.999.000', 1),
(5, '128 GB', '', '18.499.000', 2),
(6, '256 GB', '', '20.999.000', 2),
(7, '512 GB', '', '24.999.000', 2),
(8, '1 TB', '', '28.999.000', 2),
(9, '128 GB', '', '12.999.000', 3),
(10, '256 GB', '', '15.499.000', 3),
(11, '512 GB', '', '18.999.000', 3),
(12, '128 GB', '', '15.799.000', 4),
(13, '256 GB', '', '18.299.000', 4),
(14, '512 GB', '', '22.299.000', 4),
(15, '64 GB', '', '12.499.000', 5),
(16, '128 GB', '', '14.499.000', 5),
(17, '256 GB', '', '15.999.000', 5),
(18, '64 GB', '', '10.499.000', 6),
(19, '128 GB', '', '11.999.000', 6),
(20, '256 GB', '', '13.499.000', 6),
(21, '', '41 mm', '9.900.000', 7),
(22, '', '45 mm', '10.600.000', 7),
(23, '', '40 mm', '7.999.000', 8),
(24, '', '44 mm', '9.499.000', 8),
(25, '', '40 mm', '7.499.000', 9),
(26, '', '44 mm', '9.000.000', 9),
(27, '128 GB', '', '16.499.000', 10),
(28, '256 GB', '', '17.999.000', 10),
(29, '512 GB', '', '19.999.000', 10),
(30, '1 TB', '', '23.999.000', 10),
(31, '2 TB', '', '26.999.000', 10),
(32, '64 GB', '', '13.099.000', 11),
(33, '256 GB', '', '15.999.000', 11),
(34, '64 GB', '', '9.499.000', 12),
(35, '256 GB', '', '12.499.000', 12),
(36, '256 GB', '', '23.999.000', 13),
(37, '512 GB', '', '26.999.000', 13),
(38, '512 GB', '', '25.999.000', 14),
(39, '1 TB', '', '28.200.000', 14),
(40, '256 GB', '', '12.199.000', 15),
(41, '512 GB', '', '17.550.000', 15),
(42, '', '', '4.000.000', 16),
(43, '', '', '3.299.000', 17),
(44, '', '', '7.000.000', 18);

-- --------------------------------------------------------

--
-- Table structure for table `warna`
--

CREATE TABLE `warna` (
  `idwarna` int(10) NOT NULL,
  `color` varchar(20) NOT NULL,
  `idproduk` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warna`
--

INSERT INTO `warna` (`idwarna`, `color`, `idproduk`) VALUES
(1, 'Graphite', 1),
(2, 'Silver', 1),
(3, 'Gold', 1),
(4, 'Sierra Blue', 1),
(5, 'Graphite', 2),
(6, 'Silver', 2),
(7, 'Gold', 2),
(8, 'Sierra Blue', 2),
(9, 'Pink', 3),
(10, 'Blue', 3),
(11, 'Midnight', 3),
(12, 'Starlight', 3),
(13, 'Red', 3),
(14, 'Graphite', 4),
(15, 'Silver', 4),
(16, 'Gold', 4),
(17, 'Pacific Blue', 4),
(18, 'Black', 5),
(19, 'Blue', 5),
(20, 'White', 5),
(21, 'Green', 5),
(22, 'Red', 5),
(23, 'Black', 6),
(24, 'Blue', 6),
(25, 'White', 6),
(26, 'Green', 6),
(27, 'Red', 6),
(28, 'Green', 7),
(29, 'White Metallic', 7),
(30, 'Blue', 7),
(31, 'Dim Blue', 7),
(32, 'Red', 7),
(33, 'Gold', 8),
(34, 'Silver', 8),
(35, 'Gray', 8),
(36, 'Blue', 8),
(37, 'Gold', 9),
(38, 'Silver', 9),
(39, 'Gray', 9),
(40, 'Gray', 10),
(41, 'Silver', 10),
(42, 'Gray', 11),
(43, 'Silver', 11),
(44, 'Blue', 11),
(45, 'Rose Gold', 11),
(46, 'Green', 11),
(47, 'Gray', 12),
(48, 'Pink', 12),
(49, 'Purple', 12),
(50, 'Starlight', 12),
(51, 'Blue', 13),
(52, 'Green', 13),
(53, 'Red', 13),
(54, 'Silver', 13),
(55, 'Yellow', 13),
(56, 'Orange', 13),
(57, 'Silver', 14),
(58, 'Gray', 14),
(59, 'Silver', 15),
(60, 'Gray', 15),
(61, 'Gold', 15),
(62, 'White', 16),
(63, 'Black', 17),
(64, 'Silver', 18),
(65, 'Gray', 18),
(66, 'Blue', 18),
(67, 'Pink', 18),
(68, 'Green', 18);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`idproduk`);

--
-- Indexes for table `spesifikasi`
--
ALTER TABLE `spesifikasi`
  ADD PRIMARY KEY (`idspesifikasi`),
  ADD KEY `produk` (`idproduk`);

--
-- Indexes for table `warna`
--
ALTER TABLE `warna`
  ADD PRIMARY KEY (`idwarna`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `idproduk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `spesifikasi`
--
ALTER TABLE `spesifikasi`
  MODIFY `idspesifikasi` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `warna`
--
ALTER TABLE `warna`
  MODIFY `idwarna` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `spesifikasi`
--
ALTER TABLE `spesifikasi`
  ADD CONSTRAINT `produk` FOREIGN KEY (`idproduk`) REFERENCES `produk` (`idproduk`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
